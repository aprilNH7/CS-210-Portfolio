#ifndef INVESTMENT_CALCULATOR_H
#define INVESTMENT_CALCULATOR_H

class InvestmentCalculator {
public:
    InvestmentCalculator(); // Constructor

    void getInput();
    void calculateInvestment();
    void testScenarios();

private:
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int numYears;

    void calculateYearEndBalances(double additionalMonthlyDeposit = 0.0);
};

#endif // INVESTMENT_CALCULATOR_H
